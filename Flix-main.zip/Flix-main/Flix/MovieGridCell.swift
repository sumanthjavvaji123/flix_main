//
//  MovieGridCellCollectionViewCell.swift
//  Flix
//
//  Created by Malika Niazi on 9/28/21.
//

import UIKit

class MovieGridCell: UICollectionViewCell {
    
    @IBOutlet weak var posterView: UIImageView!
}
